/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c1912ladf1.tl4;

/**
 *
 * @author teacher
 */
public class Calculator {
    public int multi(int a, int b){
        return a*b;
    }
    
    public int divide(int a, int b){
        return a/b;
    }
    
    public int plus(int a, int b){
        return a+b;
    }
    
    public int minus(int a, int b){
        return a-b;
    }
    
    
    
}
