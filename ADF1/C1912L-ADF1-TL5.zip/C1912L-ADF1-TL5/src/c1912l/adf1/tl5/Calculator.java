/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c1912l.adf1.tl5;

import c1912l.adf1.tl5.culculator.CalculateFactory;

/**
 *
 * @author teacher
 */
public class Calculator {
    
    public int plus(int a, int b){
        return a+b;
    }
    
    public int minus(int a, int b){
        return a-b;
    }
    
    public int mult(int a, int b){
        return a*b;
    }
    
    public int devide(int a, int b){
        return a/b;
    }
    
}
