/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

import c1912l.adf1.tl5.Car;

/**
 *
 * @author teacher
 */
public class Runner {
    
    public static void main(String[] args) {
        Car car = new Car();
        car.start();
    }
    
}
