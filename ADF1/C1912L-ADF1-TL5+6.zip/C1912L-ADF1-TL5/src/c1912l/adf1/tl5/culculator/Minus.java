/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c1912l.adf1.tl5.culculator;

/**
 *
 * @author teacher
 */
public class Minus extends AbsCalculate{

    @Override
    public int calculate(int a, int b) {
        return a-b;
    }
    
}
